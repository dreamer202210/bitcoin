from binance.um_futures import UMFutures

client = UMFutures()
symbol = "BTCUSDT"
params = {
    "limit": 10,
}

arr = client.depth(symbol, **params)
print(arr)
print("买入价", arr["bids"][0][0])  # 取第一个价格
print("卖出价", arr["asks"][-1][0])  # 取最后一个价格

# 返回结果
# 买入价 62061.70
# 卖出价 62063.70