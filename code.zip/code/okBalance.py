from okx import Account
from env import getOkApiKey

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)
# 0实盘，1模拟盘
accountAPI = Account.AccountAPI(apiKey, apiSecretKey, passphrase, False, flag="1")
result = accountAPI.get_account_balance(ccy="USDT")
print("返回",result)
print("可用余额:", result["data"][0]["details"][0]["availBal"])
# try:
#     print("可用余额:", result["data"][0]["details"][0]["availBal"])
# except KeyError as e:
#     print(f"Key error: {e} - the key is not in the JSON structure")
