from binance.um_futures import UMFutures
from env import getApiKey

# 正式环境
# key, secret = getApiKey("apiKey","apiSecret")
# client = UMFutures(key=key, secret=secret, base_url="https://api.binance.com")

# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")

ord = client.query_order("BTCUSDT", "12345")
print(ord)