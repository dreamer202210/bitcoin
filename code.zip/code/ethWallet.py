from eth_keys import keys
from eth_account import Account
import os

# 用随机数生成新的私钥
private_key = keys.PrivateKey(os.urandom(32))
print(f"私钥: {private_key}")
# 用私钥生成公钥
public_key = private_key.public_key
# 用公钥推导出地址
address = public_key.to_checksum_address()
print(f"地址: {address}")

#运行结果
#私钥: 0x526e38807263b77729a366a8eeb9dcbee97944deb4fab299632b92bba28a44a8
#A地址: 0xbB183BB28F427C1ce72782F6f6861E803c0e9313