import urllib
import requests
import time

token = "填写你的token"
chat_id = "填写你的chat_id"


def sendMsg(msg):
    global token, chat_id
    msg2 = urllib.parse.quote_plus(msg)
    url = (
        f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={msg2}"
    )
    requests.get(url, timeout=10)


i = 0
while i < 10:
    sendMsg(f"BTCUSDT 价格 {53500+i*10}")
    time.sleep(1)
    i += 1
