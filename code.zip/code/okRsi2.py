# chatGPT优化
import argparse
from okx import MarketData
from env import getOkApiKey
import pandas as pd

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

instId = "BTC-USDT"
bar = "15m"
marketApi = MarketData.MarketAPI(
    apiKey, apiSecretKey, passphrase, use_server_time=False, flag="1"
)


def calculate_rsi(data, window=14):
    delta = data.diff()
    gain = (delta > 0) * delta
    loss = (delta < 0) * -delta

    rollUp = gain.rolling(window=window).mean()
    rollDown = loss.rolling(window=window).mean()

    rs = rollUp / rollDown
    rsi = 100 - (100 / (1 + rs))
    return rsi


def get_klines(marketApi, instId, bar, limit):
    try:
        response = marketApi.get_candlesticks(instId=instId, bar=bar, limit=limit)
        klinesData = response["data"]
        df = pd.DataFrame(
            klinesData,
            columns=["timestamp", "open", "high", "low", "close", "?", "?", "?", "?"],
        )
        df["close"] = pd.to_numeric(df["close"])
        rsi = calculate_rsi(df["close"])
        print(f"RSI: {rsi.iloc[-1]}")
        return rsi
    except Exception as e:
        print(f"Error retrieving data: {e}")
        return pd.DataFrame()


def main():

    global instId, bar
    limit = "50"

    rsi = get_klines(marketApi, instId, bar, limit)
    if rsi is not None:
        lastRsi = rsi.iloc[-1]
        print("RSI", lastRsi)
        if lastRsi >= 70:
            print("建议卖出")
        elif lastRsi <= 30:
            print("建议买入")
        else:
            print("建议持续观察")
    else:
        print("No data available to compute RSI.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--instId", "-i", type=str, help="交易对", required=True)
    parser.add_argument("--bar", "-b", type=str, help="频率", required=True)
    args = vars(parser.parse_args())
    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "instId":
            instId = args[key]
        elif key == "bar":
            bar = args[key]
    print("RSI信号策略", instId, bar)
    main()
