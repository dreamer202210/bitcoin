# 文件名：testArg.py
import argparse

parser = argparse.ArgumentParser(description="命令行参数")
#--symbol 是长参数格式 -s 是短参数格式 required=True表示此参数必须输入
parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
parser.add_argument("--qty", "-q", type=str, help="下单数量", required=True)
args = vars(parser.parse_args())
# 获取所有参数
for key in args:
    if key == "symbol":
        symbol = args[key]
        print("从命令行获得了symbol的值",symbol)
    elif key == "qty":
        qty = args[key]
        print("从命令行获得了qty的值",qty)
