from okx import Trade
from okx import Account
from env import getOkApiKey

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

# 币币市价下单，方向=buy时，sz=计价币数量quote_ccy，方向=sell时，sz=基准币数量base_ccy
# 币币市价下单
def main(symbol, sz):
    accountAPI = Account.AccountAPI(apiKey, apiSecretKey, passphrase, False, flag="1")
    acc = accountAPI.get_account_balance(ccy="USDT")
    usdtBalance = float(acc["data"][0]["details"][0]["availBal"])
    print("USDT余额:", usdtBalance)

    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )

    result = tradeAPI.place_order(
        instId=symbol,  # 交易对
        tdMode="cash",  # 模式为币币交易
        side="buy",  # 买卖方向为买入
        ordType="market",  # 订单类型为市价单
        sz=sz,  # 下单数量:20个USDT
    )
    print("币币市价买入下单结果", result)
    fillPx, fillSz = getOrd(symbol, result["data"][0]["ordId"])
    print("买入成交价格", fillPx, "成交数量", fillSz)

    result2 = tradeAPI.place_order(
        instId=symbol,  # 交易对
        tdMode="cash",  # 模式为币币交易
        side="sell",  # 买卖方向为买入
        ordType="market",  # 订单类型为市价单
        sz=fillSz,  # 下单数量，单位为BTC
    )
    print("币币市价卖出下单结果", result2)
    fillPx, fillSz = getOrd(symbol, result2["data"][0]["ordId"])
    print("卖出成交价格", fillPx, "成交数量", fillSz)
    # 卖出成交价格 69789.4 成交数量 0.00028657

    acc2 = accountAPI.get_account_balance(ccy="USDT")
    usdtBalance2 = float(acc2["data"][0]["details"][0]["availBal"])
    print("买卖后盈利:", usdtBalance2 - usdtBalance, "个USDT")
    # 买卖后盈利: -0.02002820535835781 个USDT


# 获取订单信息
def getOrd(instId, orderId):
    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )
    result = tradeAPI.get_order(instId, orderId)
    print("获取订单信息", result)
    fillPx = 0 # 成交价
    fillSz = 0 # 成交数量
    for i in range(len(result["data"])):
        fillPx += float(result["data"][i]["fillPx"])  # 累计成交价
        fillSz += float(result["data"][i]["fillSz"])  # 累计成交数量
    return fillPx / len(result["data"]), fillSz


if __name__ == "__main__":
    # 下单20个USDT
    main("BTC-USDT", 20)
