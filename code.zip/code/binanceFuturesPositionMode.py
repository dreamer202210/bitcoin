from binance.um_futures import UMFutures
from env import getApiKey
# 正式环境
# key, secret = getApiKey("apiKey", "apiSecret")
# client = UMFutures(key=key, secret=secret)
# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")
# true: 双向持仓模式,false:单向持仓模式
response = client.change_position_mode(
    dualSidePosition="true",
    recvWindow=2000
)
print(response)
