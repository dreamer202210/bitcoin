from binance.spot import Spot

# 现货账户
client = Spot()


# 深度信息,
# 参数：symbol=交易对，
#      interval=更新频率，1s, 1m, 5m, 1h, 1d
#      limit=数量，默认 500，最大 1000
def getKlines(symbol, interval, limit):
    arr = client.klines(symbol, interval, limit=limit)
    print(arr)
    # 返回数据格式[[开盘时间，开盘价，最高价，最低价，收盘价，成交量],[开盘时间，开盘价，最高价，最低价，收盘价，成交量]...]
    # [[1499040000000', "61740.30","61740.30","61659.72","61666.68","148976.11427815"]]
    lastId = len(arr) - 1  # 最后一根K线数据,也就是最新数据
    print("开盘价", arr[lastId][1])  # 开盘价
    print("最高价", arr[lastId][2])  # 最高价
    print("最低价", arr[lastId][3])  # 最低价
    print("收盘价", arr[lastId][4])  # 收盘价
    #运行结果
    #开盘价 61740.30
    #最高价 61740.30
    #最低价 61659.72
    #收盘价 61666.68


def main():
    symbol = "BTCUSDT"  # 交易对
    interval = "1m"  # 更新频率为1分钟
    limit = 10  # K线数量
    getKlines(symbol, interval, limit)


if __name__ == "__main__":
    main()
