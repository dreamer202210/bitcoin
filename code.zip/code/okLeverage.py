from okx import Account

apiKey = ""
apiSecretKey = ""
passphrase = ""
# flag:0实盘，flag:1模拟盘
accountAPI = Account.AccountAPI(apiKey, apiSecretKey, passphrase, False, flag="1")
# instId：交易对 ，lever：杠杠倍数 ， mgnMode：逐仓模式
result = accountAPI.set_leverage(instId="BTC-USDT", lever="5", mgnMode="isolated")
print(result)
#返回结果
# {'code': '0', 'data': [{'instId': 'BTC-USDT', 'lever': '5', 'mgnMode': 'isolated', 'posSide': ''}], 'msg': ''}