import urllib
import requests
from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
import json
from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler,
)

token = "填写你的token"
chat_id = "填写你的chat_id"
symbol = "BTCUSDT"
lastPrice = 0


def message_handler(_, msg):
    global symbol, lastPrice
    data = json.loads(msg)
    if data.__contains__("k"):
        print("交易对", data["k"]["s"])
        price = float(data["k"]["c"])
        print("最后1笔成交价", price)
        diff = abs(price - lastPrice)
        if lastPrice > 0 and diff > price * 0.0001:
            msg = f"{symbol}价格波动大于百分之0.01,当前价格{price}"
            print(msg)
            sendMsg(msg)
        lastPrice = price


def sendMsg(msg):
    global token, chat_id
    msg2 = urllib.parse.quote_plus(msg)
    url = (
        f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={msg2}"
    )
    requests.get(url, timeout=10)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """响应start命令"""
    text = "你好~我是币价波动监视机器人"
    await context.bot.send_message(chat_id=update.effective_chat.id, text=text)


async def price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global symbol, lastPrice
    p = f"{symbol}当前价格:{lastPrice}"
    await context.bot.send_message(chat_id=update.effective_chat.id, text=p)


def main():
    global symbol
    client = SpotWebsocketStreamClient(on_message=message_handler)
    # 订阅btcusdt最新K线数据，参数：交易对=btcusdt,频率=1秒
    client.kline(symbol=symbol, interval="1m")
    start_handler = CommandHandler("start", start)
    price_handler = CommandHandler("price", price)

    # 构建 bot
    application = ApplicationBuilder().token(token).build()
    # 注册 handler
    application.add_handler(start_handler)
    application.add_handler(price_handler)
    # run!
    application.run_polling()


if __name__ == "__main__":
    main()


# Done! Congratulations on your new bot. You will find it at t.me/PyBlockchainbot. You can now add a description, about section and profile picture for your bot, see /help for a list of commands. By the way, when you've finished creating your cool bot, ping our Bot Support if you want a better username for it. Just make sure the bot is fully operational before you do this.

# Use this token to access the HTTP API:
# 7066439594:AAHZ-M9WAb_2Csmm0zGOmUaTXf5-Jpq_dZw
# Keep your token secure and store it safely, it can be used by anyone to control your bot.

# For a description of the Bot API, see this page: https://core.telegram.org/bots/api
