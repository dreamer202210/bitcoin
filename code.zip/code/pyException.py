try:
    binanceUsdtQty = 1.5
    okxUsdtQty = "1.5"
    print("币安+欧易的USDT总余额", binanceUsdtQty+okxUsdtQty)
except Exception as e:
    print(f"程序出错: {e}")
    #程序出错: unsupported operand type(s) for +: 'float' and 'str'

# binanceUsdtQty = 1.5
# okxUsdtQty = "1.5"
# # TypeError: unsupported operand type(s) for +: 'float' and 'str'
# print("币安+欧易的USDT总余额", binanceUsdtQty+okxUsdtQty)
print("=====程序结束=====")