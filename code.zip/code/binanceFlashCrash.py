# 插针策略
import argparse
import json
import time
from binance.spot import Spot
from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
from env import getApiKey

symbol = "BTCUSDT"  # 交易对
qty = "1.0"  # 下单数量
dip = 0.01  # 下单幅度百分比
profit = 0.002  # 计划盈利
# False=还未捕捉到插针，True=已经命中
success = False
# 订单id
ordId = ""
# 下单数量的精度，也就是小数位数
qtyDecimalNum = 0

# 上次推送的时间戳
lastTm = 0

# 获取API Key和Secret
testKey, testSecret = getApiKey("testKey", "testSecret")
client = Spot(testKey, testSecret, base_url="https://testnet.binance.vision")


# 限价单
def newLimitOrd(symbol, side, price, qty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "timeInForce": "GTC",
        "quantity": qty,
        "price": price,
    }
    print(params)
    response = client.new_order(**params)  # 返回的订单信息
    ordId = response["orderId"]  # 订单ID
    return ordId


# 查询订单
def getOrder(symbol, ordId):
    try:
        ord = client.get_order(symbol, orderId=ordId)
        print(ord)
        print("订单状态", ord["status"])
        return ord
    except Exception as e:
        print(f"查询订单错误: {e}")
        return ord


# 取消订单
def cancelOrder(symbol, ordId):
    try:
        response = client.cancel_order(symbol, orderId=ordId)
        # 取消成功的话，状态是CANCELED
        print("取消订单结果", response["status"])
    except Exception as e:
        print(f"取消订单错误: {e}")


# 取消所有订单
def cancelAllOrder(symbol):
    try:
        response = client.cancel_open_orders(symbol)
        # 取消成功的话，状态是CANCELED
        print("取消所有订单", response["status"])
    except Exception as e:
        print(f"取消所有订单错误: {e}")


# 计算下单数量的精度，也就是小数位
def setqtyDecimalNum(qty):
    global qtyDecimalNum
    arr = qty.split(".")
    if len(arr) > 0:
        qtyDecimalNum = len(arr[1])
    else:
        qtyDecimalNum = 0
    print(f"设置小数位长度为{qtyDecimalNum}")


# 计算价格的精度，也就是小数位
def getPriceDecimalNum(price):
    arr = price.split(".")
    if len(arr) > 0:
        num = arr[1].rstrip("0")
        numLen = len(num)
        return numLen
    else:
        return 0


def message_handler(_, msg):
    global symbol, dip, ordId, qtyDecimalNum, profit, success, lastTm
    tm = time.time()
    during = int(tm - lastTm)
    data = json.loads(msg)
    if data.__contains__("k") and (during >= 60 or lastTm == 0 or success):
        print("交易对", data["k"]["s"], "价格", data["k"]["c"])
        # 当前收盘价
        price = float(data["k"]["c"])
        # 价格精度
        priceDecimalNum = getPriceDecimalNum(data["k"]["c"])
        print(f"当前价格={price},价格精度={priceDecimalNum},间隔时间{during}秒")
        lastTm = tm
        # 新挂单价格
        newPrice = price - price * dip
        newPrice = round(newPrice, priceDecimalNum)
        if not success and ordId != "":
            # 检查订单是否成交
            ord = getOrder(symbol, ordId)
            # 状态是NEW表示未成交
            if ord["status"] == "NEW":
                # 取消订单
                cancelOrder(symbol, ordId)
                print("取消订单id", ordId)
                # 重新挂单
                ordId = newLimitOrd(symbol, "BUY", f"{newPrice}", qty)
                print(
                    f"移动挂单:订单id={ordId},交易对={symbol},方向=BUY，价格={newPrice},数量={qty}"
                )
            elif ord["status"] == "FILLED" or ord["status"] == "PARTIALLY_FILLED":
                # 命中
                success = True
                print(f"订单id={ordId}命中")

        elif not success and ordId == "":
            # 首次挂单
            ordId = newLimitOrd(symbol, "BUY", f"{newPrice}", qty)
            print(
                f"首次挂单:订单id={ordId},交易对={symbol},方向=BUY，价格={newPrice},数量={qty}"
            )
        elif success and ordId != "":
            # 命中，计算盈利价格
            ord = getOrder(symbol, ordId)
            # 获得订单执行价格
            orderPrice = float(ord["price"])
            # 价格精度
            priceDecimalNum = getPriceDecimalNum(ord["price"])
            # 计算盈利价格
            profitPrice = orderPrice + orderPrice * profit
            # 保持正确的小数位
            profitPrice = round(profitPrice, priceDecimalNum)
            # 获取订单的执行数量
            executedQty = float(ord["executedQty"])
            # cummulativeQuoteQty = float(ord["cummulativeQuoteQty"])
            # 保持精度
            executedQty = round(executedQty, qtyDecimalNum)
            try:
                ordId2 = newLimitOrd(
                    symbol, "SELL", f"{newPrice}", f"{executedQty}"
                )
                print(
                    f"挂单信息:订单id={ordId2},交易对={symbol},方向=SELL，价格={newPrice},数量={executedQty}"
                )
                print("=======完成挂卖出单，等待成交获利=======")
                print("======退出======")
                ordId = ""
                wsClient.stop()
            except Exception as e:
                print("=======挂卖出单错误=======")
                print(e)


wsClient = SpotWebsocketStreamClient(on_message=message_handler)


def main():
    global symbol
    # 订阅btcusdt最新K线数据，参数：交易对=btcusdt,频率=1秒
    wsClient.kline(symbol=symbol, interval="1m")


if __name__ == "__main__":
    # global symbol, qty, dip, profit
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
    parser.add_argument("--qty", "-q", type=str, help="下单数量", required=True)
    parser.add_argument("--dip", "-d", type=str, help="下跌幅度百分比", required=True)
    parser.add_argument("--profit", "-p", type=str, help="盈利百分比", required=True)
    args = vars(parser.parse_args())
    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "symbol":
            symbol = args[key]
            # 取消所有订单
            cancelAllOrder(symbol)
        elif key == "qty":
            qty = args[key]
            # 设置下单数量的精度，也就是小数位数
            setqtyDecimalNum(qty)
        elif key == "dip":
            dip = float(args[key])
        elif key == "profit":
            profit = float(args[key])
    print(f"捕捉插针策略，交易对{symbol},下单数量{qty},下单幅度{dip},预计盈利{profit}")
    main()