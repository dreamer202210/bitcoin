from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
import json


def message_handler(_, msg):
    data = json.loads(msg)
    print(data)
    print("第1个买入价", data["bids"][0][0])
    print("最后1个卖出价", data["asks"][-1][0])


def main():
    client = SpotWebsocketStreamClient(on_message=message_handler)
    # 参数：交易对=btcusdt,数量=5,频率=1000毫秒
    client.partial_book_depth(symbol="btcusdt", level=5, speed=1000)

    # 文件名 binanceSpotWsDepth.py
    # 返回结果：买入价 57419.93000000
    #         卖出价 57420.49000000


if __name__ == "__main__":
    main()
