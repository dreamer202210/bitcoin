from okx import MarketData
from env import getOkApiKey
import pandas as pd

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)


def RSIStrategy(data, n=14):
    dt = data.diff()
    dt = dt[1:]
    gain = dt.copy()  # 涨幅
    loss = dt.copy()  # 跌幅
    gain[gain < 0] = 0
    loss[loss > 0] = 0
    avgGain = gain.rolling(window=n).mean()  # 涨幅均值
    avgLoss = loss.abs().rolling(window=n).mean()  # 跌幅均值
    # 计算RSI指标
    rs = avgGain / avgLoss
    rsi = 100 - (100 / (1 + rs))
    return rsi


def getKlines(instId, bar, limit):
    marketApi = MarketData.MarketAPI(
        apiKey, apiSecretKey, passphrase, use_server_time=False, flag="1"
    )
    data = marketApi.get_candlesticks(instId=instId, bar=bar, limit=limit)
    # print(data)
    klines_data = data["data"]
    print(klines_data)
    df = pd.DataFrame(
        klines_data,
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "?",
            "?",
            "?",
            "?",
        ],
    )
    # 收盘价
    df["close"] = pd.to_numeric(df["close"])
    rsi = RSIStrategy(df["close"], 14)
    print(f"RSI: {rsi}")

    lastRsi = rsi.iloc[-1]
    if lastRsi >= 70:
        print("建议卖出")
    elif lastRsi <= 30:
        print("建议买入")
    else:
        print("建议持续观察")


def main():
    instId = "BTC-USDT"  # 交易对
    bar = "15m"  # 更新频率为15分钟
    limit = "50"  # K线数量
    print("RSI信号策略", instId, bar)
    getKlines(instId, bar, limit)


if __name__ == "__main__":
    main()
