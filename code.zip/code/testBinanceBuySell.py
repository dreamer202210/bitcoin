# 测试币安买和卖流程
import json
import time
from binance.spot import Spot
from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
from env import getApiKey


# 获取API Key和Secret
testKey, testSecret = getApiKey("testKey", "testSecret")
client = Spot(testKey, testSecret, base_url="https://testnet.binance.vision")


# 限价单
def newLimitOrd(symbol, side, price, qty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "timeInForce": "GTC",
        "quantity": qty,
        "price": price,
    }
    print(params)
    response = client.new_order(**params)  # 返回的订单信息
    ordId = response["orderId"]  # 订单ID
    return ordId


# 查询订单
def getOrder(symbol, ordId):
    try:
        ord = client.get_order(symbol, orderId=ordId)
        print(ord)
        print("订单状态", ord["status"])
        return ord
    except Exception as e:
        print(f"查询订单错误: {e}")
        return {}


# 取消订单
def cancelOrder(symbol, ordId):
    try:
        response = client.cancel_order(symbol, orderId=ordId)
        # 取消成功的话，状态是CANCELED
        print("取消订单结果", response["status"])
    except Exception as e:
        print(f"取消订单错误: {e}")


# 取消所有订单
def cancelAllOrder(symbol):
    try:
        response = client.cancel_open_orders(symbol)
        # 取消成功的话，状态是CANCELED
        print("取消所有订单", response["status"])
    except Exception as e:
        print(f"取消所有订单错误: {e}")


# 计算下单数量的精度，也就是小数位
def setqtyDecimalNum(qty):
    global qtyDecimalNum
    arr = qty.split(".")
    if len(arr) > 0:
        qtyDecimalNum = len(arr[1])
    else:
        qtyDecimalNum = 0
    print(f"设置小数位长度为{qtyDecimalNum}")


# 计算价格的精度，也就是小数位
def getPriceDecimalNum(price):
    arr = price.split(".")
    if len(arr) > 0:
        num = arr[1].rstrip("0")
        numLen = len(num)
        return numLen
    else:
        return 0


def getKlines(symbol, interval, limit):
    arr = client.klines(symbol, interval, limit=limit)
    # print(arr)
    # 返回数据格式[[开盘时间，开盘价，最高价，最低价，收盘价，成交量],[开盘时间，开盘价，最高价，最低价，收盘价，成交量]...]
    # [[1499040000000', "61740.30","61740.30","61659.72","61666.68","148976.11427815"]]
    lastId = len(arr) - 1  # 最后一根K线数据,也就是最新数据
    print("开盘价", arr[lastId][1])  # 开盘价
    print("最高价", arr[lastId][2])  # 最高价
    print("最低价", arr[lastId][3])  # 最低价
    print("收盘价", arr[lastId][4])  # 收盘价
    return arr[lastId][4]


def main():
    symbol = "BTCUSDT"  # 交易对
    interval = "1m"  # 更新频率为1分钟
    limit = 10  # K线数量
    cancelAllOrder(symbol)
    close = getKlines(symbol, interval, limit)
    print("市价", close)
    closeF = float(close)
    # 按低于市价0.005%价格购买
    closeF -= closeF * 0.0003
    # 价格精度
    priceDecimalNum = getPriceDecimalNum(close)
    closeF = round(closeF, priceDecimalNum)
    qty = 0.001
    qtyDecimalNum = 3
    ordId = newLimitOrd(symbol, "BUY", f"{closeF}", qty)
    print(f"挂买单:订单id={ordId},交易对={symbol},方向=BUY，价格={closeF},数量={qty}")
    while True:
        try:
            # 检查订单是否成交
            ord = getOrder(symbol, ordId)
            # 状态是NEW表示未成交
            if ord["status"] == "NEW":
                time.sleep(10)
            elif ord["status"] == "FILLED" or ord["status"] == "PARTIALLY_FILLED":
                # 命中
                print(f"订单id={ordId}命中")
                # 获得订单执行价格
                orderPrice = float(ord["price"])
                # 价格精度
                priceDecimalNum = getPriceDecimalNum(ord["price"])
                # 计算盈利价格
                profitPrice = orderPrice + orderPrice * 0.0005
                # 保持正确的小数位
                profitPrice = round(profitPrice, priceDecimalNum)
                # 开始卖出
                # 获取订单的执行数量
                executedQty = float(ord["executedQty"])
                print("执行数量", executedQty)
                # cummulativeQuoteQty = float(ord["cummulativeQuoteQty"])
                # 保持精度
                executedQty = round(executedQty, qtyDecimalNum)
                print("执行数量,保持精度", executedQty)
                try:
                    ordId2 = newLimitOrd(
                        symbol, "SELL", f"{profitPrice}", f"{executedQty}"
                    )
                    print(
                        f"挂单信息:订单id={ordId2},交易对={symbol},方向=SELL，价格={profitPrice},数量={executedQty}"
                    )
                    print("=======完成挂卖出单，等待成交获利=======")
                    print("======退出======")
                    break
                except Exception as e:
                    print("=======挂卖出单错误=======")
                    print(e)
        except Exception as e:
            print(f"查询订单错误: {e}")
            time.sleep(10)


if __name__ == "__main__":
    print("测试币安买和卖的流程")
    main()
