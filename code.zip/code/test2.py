import time

#当前时间戳，1713342339.2257404
start=time.time()
#print(start)

def takeTime():
    #时间戳单位是秒
    t = int(time.time()-start)
    return f"{t}秒"

def taskA():
    print("运行任务A")
    time.sleep(10)
    

def taskB():
    print("运行任务B")
    time.sleep(10)


taskA()
taskB()
print(f"任务结束!!耗时{takeTime()}")
    