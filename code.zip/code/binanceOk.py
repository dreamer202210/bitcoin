from binance.spot import Spot
from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
import asyncio
from okx.websocket.WsPublicAsync import WsPublicAsync
from okx import Trade
from env import getOkApiKey
import json

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

bianceBtc = 0  # 币安价格
okBtc = 0  # 欧易价格


# 币安下市价单
def marketOrder(symbol, side, qty):
    # key, secret = getApiKey("apiKey","apiSecret")
    # client = Spot(key, secret, base_url="https://api.binance.com")
    # 测试网
    testKey, testSecret = getApiKey("testKey", "testSecret")
    client = Spot(testKey, testSecret, base_url="https://testnet.binance.vision")

    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "timeInForce": "GTC",
        "quantity": qty,
    }
    response = client.new_order(**params)
    print(response)


# 欧易下市价单
def OkMarketOrder(symbol, side, qty):
    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )
    result = tradeAPI.place_order(
        instId=symbol,  # 交易对
        tdMode="cash",  # 模式为币币交易
        side=side,  # 买卖方向
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量
    )
    print("欧易币币市价下单结果", result)


def message_handler(_, msg):
    data = json.loads(msg)
    price = data["k"]["c"]
    global okBtc
    global bianceBtc
    bianceBtc = float(price)
    print("币安btc", bianceBtc, "欧易btc", okBtc, "价差", round(bianceBtc - okBtc, 8))


def publicCallback(msg):
    global okBtc
    global bianceBtc
    try:
        msg = json.loads(msg)
        data = msg["data"]
        arrLen = len(data)  # 行情数据的行数
        if arrLen > 0:
            okBtc = float(data[arrLen - 1][3])  # 最后一行第4列数据是最新收盘价格
            print(
                "币安btc",
                bianceBtc,
                "欧易btc",
                okBtc,
                "价差",
                round(bianceBtc - okBtc, 8),
            )
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
    except KeyError as e:
        print(f"Key error: {e} - the key is not in the JSON structure")


async def main():
    print("币安和欧易价差套利策略")
    # 币安
    client = SpotWebsocketStreamClient(on_message=message_handler)
    # 订阅btcusdt最新K线数据，参数：交易对=btcusdt,频率=1秒
    client.kline(symbol="BTCUSDT", interval="1m")

    # 欧易
    url = "wss://wsaws.okx.com:8443/ws/v5/business"
    ws = WsPublicAsync(url=url)
    await ws.start()
    args = []
    arg1 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "BTC-USDT"}
    args.append(arg1)
    await ws.subscribe(args, publicCallback)
    # await asyncio.sleep(20)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())

# 运行结果
# 币安btc 63029.25 欧易btc 62959.4 价差 69.85
# 币安btc 63038.99 欧易btc 62959.4 价差 79.59
# 币安btc 63038.99 欧易btc 62959.4 价差 79.59
# 币安btc 63039.0 欧易btc 62959.4 价差 79.6
# 币安btc 63020.01 欧易btc 62959.4 价差 60.61
# 币安btc 63012.03 欧易btc 62959.4 价差 52.63
# 币安 提币手续费 0.0002
# 欧易 提币手续费 0.0002