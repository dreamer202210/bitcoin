import urllib
import requests
import asyncio
import json

from okx.websocket.WsPublicAsync import WsPublicAsync
token = "填写你的token"
chat_id = "填写你的chat_id"
symbol = "BTC-USDT"
lastPrice = 0


def publicCallback(message):
    global lastPrice
    try:
        msg = json.loads(message)
        # print("数据", msg)
        print(msg["arg"]["instId"])
        price = float(msg["data"][0][3])
        print("价格", price)
        diff = abs(price - lastPrice)
        if lastPrice > 0 and diff > price * 0.0001:
            msg = f"欧易交易所，{symbol}价格波动大于百分之0.01,当前价格{price}"
            print(msg)
            sendMsg(msg)
        lastPrice = price
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
    except KeyError as e:
        print(f"Key error: {e} - the key is not in the JSON structure")


def sendMsg(msg):
    global token, chat_id
    msg2 = urllib.parse.quote_plus(msg)
    url = (
        f"https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={msg2}"
    )
    requests.get(url, timeout=10)


async def getKline():
    global symbol
    url = "wss://wsaws.okx.com:8443/ws/v5/business"
    ws = WsPublicAsync(url=url)
    await ws.start()
    args = []
    arg1 = {"channel": "index-candle1m", "instType": "SPOT", "instId": symbol}
    args.append(arg1)
    await ws.subscribe(args, publicCallback)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(getKline())
