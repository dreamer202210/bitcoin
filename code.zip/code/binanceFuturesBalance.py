#!/usr/bin/env python
from binance.um_futures import UMFutures
from env import getApiKey

key, secret = getApiKey("apiKey", "apiSecret")

# 合约账户
client = UMFutures(key=key, secret=secret)


# 合约账户余额
def getBalance(asset):
    arr = client.balance(ecvWindow=5000)
    print(arr)
    for item in arr:
        if item["asset"] == asset:
            return float(item["availableBalance"])
    return 0.00000000


def main():
    balance = getBalance("USDT")
    print("合约账户USDT余额", balance)


if __name__ == "__main__":
    main()
