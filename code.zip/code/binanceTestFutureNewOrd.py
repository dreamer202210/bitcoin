from binance.um_futures import UMFutures
from env import getApiKey

# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")


def NewOrd(symb, side, qty2, positionSide):
    # 开仓或平仓
    res = client.new_order(
        symbol=symb,
        side=side,
        type="MARKET",
        quantity=qty2,
        positionSide=positionSide,
    )
    print("开仓或平仓")
    print(res)
    return res


def getOrdInfo(symbol, orderId):
    ord = client.query_order(symbol, orderId)
    print("查询订单信息")
    print(ord)


res1 = NewOrd("BTCUSDT", "SELL", 0.002, "SHORT")
getOrdInfo("BTCUSDT", res1["orderId"])

res2 = NewOrd("BTCUSDT", "BUY", 0.002, "SHORT")
getOrdInfo("BTCUSDT", res2["orderId"])

# 开仓信息
# {
#     "orderId": 3789592944,
#     "symbol": "BTCUSDT",
#     "status": "NEW",
#     "clientOrderId": "pz5FGOkY1vX9sErfYEIQiu",
#     "price": "0.00",
#     "avgPrice": "0.00",
#     "origQty": "0.002",
#     "executedQty": "0.000",
#     "cumQty": "0.000",
#     "cumQuote": "0.00000",
#     "timeInForce": "GTC",
#     "type": "MARKET",
#     "reduceOnly": False,
#     "closePosition": False,
#     "side": "SELL",
#     "positionSide": "SHORT",
#     "stopPrice": "0.00",
#     "workingType": "CONTRACT_PRICE",
#     "priceProtect": False,
#     "origType": "MARKET",
#     "priceMatch": "NONE",
#     "selfTradePreventionMode": "NONE",
#     "goodTillDate": 0,
#     "updateTime": 1712803175215,
# }
# 查询订单信息
# {
#     "orderId": 3789592944,
#     "symbol": "BTCUSDT",
#     "status": "FILLED",
#     "clientOrderId": "pz5FGOkY1vX9sErfYEIQiu",
#     "price": "0.00",
#     "avgPrice": "72149.80000",
#     "origQty": "0.002",
#     "executedQty": "0.002",
#     "cumQuote": "144.29960",
#     "timeInForce": "GTC",
#     "type": "MARKET",
#     "reduceOnly": False,
#     "closePosition": False,
#     "side": "SELL",
#     "positionSide": "SHORT",
#     "stopPrice": "0.00",
#     "workingType": "CONTRACT_PRICE",
#     "priceProtect": False,
#     "origType": "MARKET",
#     "priceMatch": "NONE",
#     "selfTradePreventionMode": "NONE",
#     "goodTillDate": 0,
#     "time": 1712803175215,
#     "updateTime": 1712803175215,
# }
