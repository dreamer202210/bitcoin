from binance.um_futures import UMFutures
from env import getApiKey
import time

# 正式环境
# key, secret = getApiKey("apiKey","apiSecret")
# client = UMFutures(key=key, secret=secret, base_url="https://api.binance.com")

# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")

qty = 0.02
# 开仓做多
response = client.new_order(
    symbol="BTCUSDT",
    side="BUY",
    type="MARKET",
    quantity=qty,
    positionSide="LONG",
    # timeInForce="GTC",
)
print("开仓")
print(response)
# time.sleep(10)

# 下单的买卖方向和持仓方向一致，就是合仓操作，持仓数量进行累加
# response = client.new_order(
#     symbol="BTCUSDT",
#     side="BUY",
#     type="MARKET",
#     quantity=qty,
#     positionSide="LONG",
#     # timeInForce="GTC",
# )
# print("合仓操作")
# print(response)
# time.sleep(10)

# 平仓，下单的买卖方向相反，持仓方向一致，就是平仓
# response = client.new_order(
#     symbol="BTCUSDT",
#     side="SELL",
#     type="MARKET",
#     quantity=qty,
#     positionSide="LONG",
#     # timeInForce="GTC",
# )
# print("平仓")
# print(response)

# 设置止盈，买卖方向要和开仓买卖方向相反，持仓方向要一致
response = client.new_order(
    symbol="BTCUSDT",
    side="SELL",
    type="TAKE_PROFIT_MARKET",
    timeInForce="GTC",
    stopPrice=64100,
    quantity=qty,
    positionSide="LONG",
)
print("设置止盈")
print(response)

# 设置止损，买卖方向要和开仓买卖方向相反，持仓方向要一致
response = client.new_order(
    symbol="BTCUSDT",
    side="SELL",
    type="TRAILING_STOP_MARKET",
    timeInForce="GTC",
    activatePrice=62500,
    callbackRate=1,
    quantity=qty,
    positionSide="LONG",
)
print("设置止损")
print(response)


# 开多：买入开多（side 填写 buy； posSide 填写 long ）
# 开空：卖出开空（side 填写 sell； posSide 填写 short ）
# 平多：卖出平多（side 填写 sell；posSide 填写 long ）
# 平空：买入平空（side 填写 buy； posSide 填写 short ）