from binance.um_futures import UMFutures
from env import getApiKey

key, secret = getApiKey("apiKey", "apiSecret")
client = UMFutures(key=key, secret=secret)
response = client.change_leverage(
        symbol="BTCUSDT", leverage=10, recvWindow=6000
)
print(response)
# 返回结果
# leverage 杠杠倍数
# maxNotionalValue 最大名义价值
# {'symbol': 'BTCUSDT', 'leverage': 10, 'maxNotionalValue': '150000000'}