import random
import time


from telegram import Update
from telegram.ext import (
    ApplicationBuilder,
    ContextTypes,
    CommandHandler,
    filters,
    MessageHandler,
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """响应start命令"""
    text = "你好~我是币价波动监视机器人"
    await context.bot.send_message(chat_id=update.effective_chat.id, text=text)


async def price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    p = "当前币价:63001USD"
    await context.bot.send_message(chat_id=update.effective_chat.id, text=p)


async def price_monitor(update: Update, context: ContextTypes.DEFAULT_TYPE):
    while True:
        await context.bot.send_message(
            chat_id=update.effective_chat.id, text="最新币价消息"
        )
        time.sleep(60)  # Wait for 1 minutes


start_handler = CommandHandler("start", start)
price_handler = CommandHandler("price", price)

# 构建 bot
TOKEN = "填写你的token"
application = ApplicationBuilder().token(TOKEN).build()
# 注册 handler
application.add_handler(start_handler)
application.add_handler(price_handler)
# run!
application.run_polling(price_monitor)


# {
#     "ok": true,
#     "result": [
#         {
#             "update_id": 607025435,
#             "message": {
#                 "message_id": 32,
#                 "from": {
#                     "id": 5495417115,
#                     "is_bot": false,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "language_code": "zh-hans",
#                 },
#                 "chat": {
#                     "id": 5495417115,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "type": "private",
#                 },
#                 "date": 1714362050,
#                 "text": "/start",
#                 "entities": [{"offset": 0, "length": 6, "type": "bot_command"}],
#             },
#         },
#         {
#             "update_id": 607025436,
#             "message": {
#                 "message_id": 33,
#                 "from": {
#                     "id": 5495417115,
#                     "is_bot": false,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "language_code": "zh-hans",
#                 },
#                 "chat": {
#                     "id": 5495417115,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "type": "private",
#                 },
#                 "date": 1714362057,
#                 "text": "/price",
#                 "entities": [{"offset": 0, "length": 6, "type": "bot_command"}],
#             },
#         },
#         {
#             "update_id": 607025437,
#             "message": {
#                 "message_id": 36,
#                 "from": {
#                     "id": 5495417115,
#                     "is_bot": false,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "language_code": "zh-hans",
#                 },
#                 "chat": {
#                     "id": 5495417115,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "type": "private",
#                 },
#                 "date": 1714365182,
#                 "text": "/",
#             },
#         },
#         {
#             "update_id": 607025438,
#             "message": {
#                 "message_id": 39,
#                 "from": {
#                     "id": 5495417115,
#                     "is_bot": false,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "language_code": "zh-hans",
#                 },
#                 "chat": {
#                     "id": 5495417115,
#                     "first_name": "nin",
#                     "last_name": "ki",
#                     "username": "ninki51",
#                     "type": "private",
#                 },
#                 "date": 1714365193,
#                 "text": "/",
#             },
#         },
#     ],
# }
