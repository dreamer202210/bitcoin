# 插针策略
import argparse
import asyncio
import json
import time
from okx import Trade
from okx.websocket.WsPublicAsync import WsPublicAsync
from env import getOkApiKey

symbol = "BTCUSDT"  # 交易对
qty = "1.0"  # 下单数量
dip = 0.01  # 下单幅度百分比
profit = 0.002  # 计划盈利
# False=还未捕捉到插针，True=已经命中
success = False
# 订单id
ordId = ""
# 小数位数
decimalNum = 0

# 上次推送的时间戳
lastTm = 0

# 获取API Key和Secret
apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)
tradeAPI = Trade.TradeAPI(
    apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
)


# 限价单
def newLimitOrd(instId, side, price, sz):
    result = tradeAPI.place_order(
        instId=instId,  # 交易对
        tdMode="cash",  # 币币交易
        side=side,  # 买入
        ordType="limit",  # 限价
        sz=sz,  # 数量
        px=price,  # 委托价格
    )
    print("币币限价下单结果", result)
    orderId = 0
    if result["code"] == "0":
        orderId = result["data"][0]["ordId"]
        print("orderId", orderId)
    return orderId


# 查询订单
def getOrder(instId, ordId):
    try:
        result = tradeAPI.get_order(instId, ordId)
        print("获取订单信息", result)
        if len(result["data"]) > 0:
            state = result["data"][0]["state"]
            print("订单状态", state)
        return result
    except Exception as e:
        print(f"查询订单错误: {e}")
        return ord


# 取消订单
def cancelOrder(instId, ordId):
    try:
        result = tradeAPI.cancel_order(instId, ordId)
        print("取消订单结果", result)
    except Exception as e:
        print(f"取消订单错误: {e}")


# 计算小数位
def setDecimalNum(qty):
    global decimalNum
    arr = qty.split(".")
    if len(arr) > 0:
        decimalNum = len(arr[1])
    else:
        decimalNum = 0
    print(f"设置小数位长度为{decimalNum}")

# 计算价格的精度，也就是小数位
def getPriceDecimalNum(price):
    arr = price.split(".")
    if len(arr) > 0:
        num = arr[1].rstrip("0")
        numLen = len(num)
        return numLen
    else:
        return 0


def message_handler(msg):
    global symbol, dip, ordId, decimalNum, profit, success, lastTm
    tm = time.time()
    during = int(tm - lastTm)
    data = json.loads(msg)
    if data.__contains__("data") and (during >= 60 or lastTm == 0 or success):
        print("交易对", print(data["arg"]["instId"]))
        # 当前收盘价
        price = float(data["data"][0][3])
        print(f"当前价格====={price},间隔时间={during}秒")
        lastTm = tm
        # 新挂单价格
        newPrice = price - price * dip
        newPrice = round(newPrice, decimalNum)
        if not success and ordId != "":
            # 检查订单是否成交
            ord = getOrder(symbol, ordId)
            # 状态是NEW表示未成交
            if ord["data"][0]["state"] == "live":
                # 取消订单
                cancelOrder(symbol, ordId)
                print("取消订单id", ordId)
                # 重新挂单
                ordId = newLimitOrd(symbol, "buy", f"{newPrice}", qty)
                print(
                    f"移动挂单:订单id={ordId},交易对={symbol},方向=buy，价格={newPrice},数量={qty}"
                )
            elif (
                ord["data"][0]["state"] == "filled"
                or ord["data"][0]["state"] == "partially_filled"
            ):
                # 命中
                success = True
                print(f"订单id={ordId}命中")

        elif not success and ordId == "":
            # 首次挂单
            ordId = newLimitOrd(symbol, "buy", f"{newPrice}", qty)
            print(
                f"首次挂单:订单id={ordId},交易对={symbol},方向=buy，价格={newPrice},数量={qty}"
            )
        elif success and ordId != "":
            # 命中，计算盈利价格
            ord = getOrder(symbol, ordId)
            # 获得订单执行价格
            orderPrice = float(ord["price"])
            # 计算盈利价格
            profitPrice = orderPrice + orderPrice * profit
            # 保持正确的小数位
            priceDecimalNum = getPriceDecimalNum(ord["price"])
            profitPrice = round(profitPrice, priceDecimalNum)
            # 获取订单的执行数量
            fillSz = ord["fillSz"]
            try:
                ordId2 = newLimitOrd(symbol, "sell", f"{profitPrice}", fillSz)
                print(
                    f"挂单信息:订单id={ordId2},交易对={symbol},方向=sell，价格={profitPrice},数量={fillSz}"
                )
                print("=======完成挂卖出单，等待成交获利=======")
                print("======退出======")
                ordId = ""
                args = []
                arg1 = {
                    "channel": "index-candle1m",
                    "instType": "SPOT",
                    "instId": symbol,
                }
                args.append(arg1)
                ws.unsubscribe(args, message_handler)
                return
            except Exception as e:
                print("=======挂卖出单错误=======")
                print(e)


async def main():
    ws = WsPublicAsync(url="wss://wsaws.okx.com:8443/ws/v5/business")
    await ws.start()
    args = []
    arg1 = {"channel": "index-candle1m", "instType": "SPOT", "instId": symbol}
    args.append(arg1)
    await ws.subscribe(args, message_handler)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    # global symbol, qty, dip, profit
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
    parser.add_argument("--qty", "-q", type=str, help="下单数量", required=True)
    parser.add_argument("--dip", "-d", type=str, help="下跌幅度百分比", required=True)
    parser.add_argument("--profit", "-p", type=str, help="盈利百分比", required=True)
    args = vars(parser.parse_args())
    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "symbol":
            symbol = args[key]
        elif key == "qty":
            qty = args[key]
            # 设置小数位数
            setDecimalNum(qty)
        elif key == "dip":
            dip = float(args[key])
        elif key == "profit":
            profit = float(args[key])
    print(
        f"欧易捕捉插针策略，交易对{symbol},下单数量{qty},下单幅度{dip},预计盈利{profit}"
    )
    asyncio.run(main())