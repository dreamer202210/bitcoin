import pandas as pd
from binance.spot import Spot

# 现货账户
client = Spot()


def macdStrategy(macd, signal):
    if (
        isinstance(macd, pd.Series)
        and isinstance(signal, pd.Series)
        and len(macd) > 1
        and len(signal) > 1
    ):
        if macd.iloc[-1] > signal.iloc[-1]:  # 金叉
            return "建议买入"
        elif macd.iloc[-1] < signal.iloc[-1]:  # 死叉
            return "建议卖出"
        else:
            return "拿住"
    else:
        return "Not enough data to calculate MACD and Signal."


def getKlines(symbol, interval, limit):
    klines_data = client.klines(symbol, interval, limit=limit)
    # print(klines_data)
    if all(isinstance(i, list) for i in klines_data):
        df = pd.DataFrame(
            klines_data,
            columns=[
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "?",
                "?",
                "?",
                "?",
                "?",
                "?",
            ],
        )
        # Convert the 'close' and 'open' columns to numeric values
        df["close"] = pd.to_numeric(df["close"])
        df["open"] = pd.to_numeric(df["open"])

        # Calculate the MACD and Signal lines
        exp1 = df["close"].ewm(span=12, adjust=False).mean()
        exp2 = df["close"].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        decision = macdStrategy(macd, signal)
        print(f"MACD交易决策建议: {decision}")
    else:
        print("Invalid klines data structure.")


def main():
    symbol = "BTCUSDT"  # 交易对
    interval = "15m"  # 更新频率为1分钟
    limit = 50  # K线数量
    print("MACD信号策略", symbol, interval)
    getKlines(symbol, interval, limit)


if __name__ == "__main__":
    main()
