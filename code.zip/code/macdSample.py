import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# plt.rcParams['font.family'] = 'SimSun'  # 替换为你选择的字体

# Simulating stock data with more pronounced golden and dead crosses
np.random.seed(42)
dates = pd.date_range('20230501', periods=200)
prices = np.sin(np.linspace(-3*np.pi, 3*np.pi, 200)) * 45 + np.random.normal(0, 1, 200) + 100
stock_data = pd.DataFrame(prices, index=dates, columns=['Close'])

# Calculating the short-term and long-term EMAs
ShortEMA = stock_data['Close'].ewm(span=12, adjust=False).mean()
LongEMA = stock_data['Close'].ewm(span=26, adjust=False).mean()

# Calculating the MACD line (DIF) and the signal line (DEA)
MACD = ShortEMA - LongEMA
signal = MACD.ewm(span=9, adjust=False).mean()

# Plotting the simulated stock price and the MACD indicators
plt.figure(figsize=(14, 7))
plt.plot(stock_data.index, stock_data['Close'], label='Simulated Close Price', color='skyblue')
plt.plot(stock_data.index, MACD, label='MACD Line (DIF)', color='blue')
plt.plot(stock_data.index, signal, label='Signal Line (DEA)', color='red')

# Highlighting the golden cross and dead cross
golden_crosses = stock_data[(MACD.shift(1) < signal.shift(1)) & (MACD > signal)]
dead_crosses = stock_data[(MACD.shift(1) > signal.shift(1)) & (MACD < signal)]

plt.scatter(golden_crosses.index, stock_data['Close'][golden_crosses.index], marker='^', color='green', label='Golden Cross', s=100)
plt.scatter(dead_crosses.index, stock_data['Close'][dead_crosses.index], marker='v', color='red', label='Dead Cross', s=100)

# Adding labels and title
plt.title('Simulated Stock Price with MACD, Golden Cross, and Dead Cross')
plt.xlabel('Date')
plt.ylabel('Simulated Price')
plt.legend(loc='upper left')

# Show the plot
plt.show()
