from binance.um_futures import UMFutures
from env import getApiKey

key, secret = getApiKey("apiKey", "apiSecret")
client = UMFutures(key=key, secret=secret)
# marginType 值选项：[CROSSED全仓，ISOLATED逐仓]
response = client.change_margin_type(
    symbol="BTCUSDT", marginType="CROSSED", recvWindow=6000
)
print(response)
