import time
import json
from binance.websocket.um_futures.websocket_client import UMFuturesWebsocketClient


# 接收推送数据
def message_handler(_, msg):
    data = json.loads(msg)
    #print(data)
    print("交易对", data["k"]["s"])
    print("第一笔成交价", data["k"]["o"])
    print("最后一笔成交价", data["k"]["c"])
    print("最高成交价", data["k"]["h"])
    print("最低成交价", data["k"]["l"])
    print("成交量", data["k"]["v"])
    # 运行结果
    # 交易对 BTCUSDT
    # 第一笔成交价 62040.00
    # 最后一笔成交价 62060.70
    # 最高成交价 62060.70
    # 最低成交价 62039.90
    # 成交量 41.368


client = UMFuturesWebsocketClient(on_message=message_handler)

client.kline(
    symbol="BTCUSDT",
    interval="1m",
)

# time.sleep(10) #休眠10秒
# client.stop() #停止接收推送
