import argparse
import pandas as pd
from binance.um_futures import UMFutures
from env import getApiKey
import time

# 正式环境
# key, secret = getApiKey("apiKey","apiSecret")
# client = UMFutures(key=key, secret=secret, base_url="https://api.binance.com")

# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")

# 做多状态
longStat = False
# 做空状态
shortStat = False
symbol = "BTCUSDT"  # 交易对
qty = 0.002  # 下单数量BTC
lastPrice = 0  # 开仓价格
profit = 0.01  # 止盈点


# MACD信号
def macdStrategy(macd, signal):
    global symbol, qty, longStat, shortStat, lastPrice

    if (
        isinstance(macd, pd.Series)
        and isinstance(signal, pd.Series)
        and len(macd) > 1
        and len(signal) > 1
    ):
        if macd.iloc[-1] > signal.iloc[-1]:  # 金叉
            print("出现金叉，建议做多")
            if not longStat:
                # 未开多则开多
                print("开仓做多")
                ord = NewOrd(symbol, "BUY", qty, "LONG")
                ordInfo = getOrder(symbol, ord["orderId"])
                lastPrice = float(ordInfo["avgPrice"])

                longStat = True
            if shortStat:
                # 如果开空则平空
                print("平空")
                NewOrd(symbol, "BUY", qty, "SHORT")
                shortStat = False

        elif macd.iloc[-1] < signal.iloc[-1]:  # 死叉
            print("出现死叉，建议做空")
            if not shortStat:
                # 未开空则开空
                print("开仓做空")
                ord = NewOrd(symbol, "SELL", qty, "SHORT")
                ordInfo = getOrder(symbol, ord["orderId"])
                lastPrice = float(ordInfo["avgPrice"])
                shortStat = True
            if longStat:
                # 如果开多则平多
                print("平多")
                NewOrd(symbol, "SELL", qty, "LONG")
                shortStat = False
        else:
            print("什么也不用做")
    else:
        print("数据不足")


def getKlines(symbol2, interval, limit):
    global client
    klines_data = client.klines(symbol2, interval, limit=limit)
    # print(klines_data)
    if all(isinstance(i, list) for i in klines_data):
        df = pd.DataFrame(
            klines_data,
            columns=[
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "?",
                "?",
                "?",
                "?",
                "?",
                "?",
            ],
        )
        df["close"] = pd.to_numeric(df["close"])
        df["open"] = pd.to_numeric(df["open"])

        # 计算MACD指标
        exp1 = df["close"].ewm(span=12, adjust=False).mean()
        exp2 = df["close"].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        macdStrategy(macd, signal)
        if lastPrice > 0:
            lastId = len(klines_data) - 1
            if longStat:
                # 做多利润
                diff = float(klines_data[lastId][4]) - lastPrice
                print("做多利润", diff * qty)
                if diff > profit:
                    # 达到止盈点，平仓
                    ord = NewOrd(symbol, "SELL", qty, "LONG")
                    ordInfo = getOrder(symbol, ord["orderId"])
                    if ordInfo["status"] == "FILLED":
                        print("平仓完成")
            elif shortStat:
                # 做空利润
                diff = lastPrice - float(klines_data[lastId][4])
                print("做空利润", diff * qty)
                if diff > profit:
                    # 达到止盈点，平仓
                    ord = NewOrd(symbol, "BUY", qty, "SHORT")
                    ordInfo = getOrder(symbol, ord["orderId"])
                    if ordInfo["status"] == "FILLED":
                        print("平仓完成")
    else:
        print("Invalid klines data structure.")


def NewOrd(symb, side, qty2, positionSide):
    global client
    # 开仓或平仓
    res = client.new_order(
        symbol=symb,
        side=side,
        type="MARKET",
        quantity=qty2,
        positionSide=positionSide,
        # timeInForce="GTC",
    )
    print("开仓或平仓")
    print(res)
    return res


# 合约账户余额
def getBalance(asset):
    global client
    arr = client.balance(ecvWindow=5000)
    print(arr)
    for item in arr:
        if item["asset"] == asset:
            return float(item["availableBalance"])
    return 0.00000000


# 设置杠杠倍数
def setLeverage(leverage):
    global client
    client.change_leverage(symbol=symbol, leverage=leverage, recvWindow=6000)


# 设置逐仓模式
def setMargin():
    global client
    client.change_margin_type(symbol=symbol, marginType="CROSSED", recvWindow=6000)


# 查询订单
def getOrder(symb, orderId):
    ord = client.query_order(symb, orderId)
    return ord


def main():
    global symbol, qty, profit
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
    parser.add_argument("--qty", "-q", type=float, help="下单数量", required=True)
    parser.add_argument(
        "--profit", "-p", type=float, help="止盈点", default=0.01, required=True
    )
    args = vars(parser.parse_args())

    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "symbol":
            symbol = args[key]
        elif key == "qty":
            qty = args[key]
        elif key == "profit":
            profit = args[key]
    print(symbol, qty, profit)
    # 设置杠杠倍数
    setLeverage(1)
    # 设置逐仓模式
    # setMargin()
    balance = getBalance("USDT")
    print("合约账户USDT余额", balance)

    interval = "15m"  # K线间隔为15分钟
    limit = 50  # K线数量
    print("MACD信号策略", symbol, interval)

    while True:
        getKlines(symbol, interval, limit)
        time.sleep(30)  # 休眠30秒


if __name__ == "__main__":
    main()
