#全局变量 
profit = 0
#计算利润的函数，返回利润值
def getProfit(buyPrice,sellPrice):
    global profit
    #此时buyPrice的传入值是56300
    #buyPrice的传入值是57000
    #手续费0.1%
    fee = 0.001
    #修改全局变量
    profit = sellPrice-buyPrice-sellPrice*fee
    

#调用函数,括号中传入参数
getProfit(56300,57000)
print("利润",profit)
