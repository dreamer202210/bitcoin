from binance.spot import Spot
from env import getApiKey

# 测试网
key, secret = getApiKey("apiKey", "apiSecret")
client = Spot(key, secret, base_url="https://api-gcp.binance.com")
# client = Spot(key, secret, base_url="https://testnet.binance.vision")


# 限价单
def newLimitOrd(symbol, side, price, qty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "timeInForce": "GTC",
        "quantity": qty,
        "price": price,
    }
    response = client.new_order(**params)  # 返回的订单信息
    ordId = response["orderId"]  # 订单ID
    return ordId


# 市价单
def newMarketOrd(symbol, side, qty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": qty,
    }
    response = client.new_order(**params)
    ordId = response["orderId"]  # 订单ID
    return ordId


# 查询订单
def getOrder(symbol, ordId):
    ord = client.get_order(symbol, orderId=ordId)
    print(ord)
    print("订单状态", ord["status"])
    return ord


# 取消订单
def cancelOrder(symbol, ordId):
    response = client.cancel_order(symbol, orderId=ordId)
    # 取消成功的话，状态是CANCELED
    print("取消订单结果", response["status"])


def main():
    # 限价单，以60000的价格购买0.001个BTC
    symbol = "ETHUSDT"
    orderId1 = newLimitOrd(symbol, "SELL", "3500", "0.0499")
    print("下单结果", orderId1)

    ord1 = getOrder(symbol, orderId1)
    print("查询限价单状态", ord1["status"])
    # if ord1["status"] == "NEW":
    #     cancelOrder(symbol, orderId1)
    # 市价单，以市场价格购买0.001个BTC
    # orderId2 = newMarketOrd(symbol, "BUY", "0.0499")
    # ord2 = getOrder(symbol, "2848621")
    # print("市价单状态", ord2["status"])


if __name__ == "__main__":
    main()
