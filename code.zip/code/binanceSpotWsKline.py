from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
import json


def message_handler(_, msg):
    data = json.loads(msg)
    print("交易对", data["k"]["s"])
    print("最后1笔成交价", data["k"]["c"])


def main():
    client = SpotWebsocketStreamClient(on_message=message_handler)
    # 订阅btcusdt最新K线数据，参数：交易对=btcusdt,频率=1秒
    client.kline(symbol="btcusdt", interval="1m")

    # 运行结果
    # 交易对 BTCUSDT
    # 最后1笔成交价 61350.44000000


if __name__ == "__main__":
    main()
