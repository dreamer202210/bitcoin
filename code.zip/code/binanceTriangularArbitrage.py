import json
from binance.spot import Spot
from binance.websocket.spot.websocket_stream import SpotWebsocketStreamClient
from env import getApiKey

# 初始化三个交易对的状态，0为等待状态
btcusdtWaitStatus = 0
ethbtcWaitStatus = 0
ethusdtWaitStatus = 0
btcusdt = 0
ethbtc = 0
ethusdt = 0

# Retrieve API keys
testKey, testSecret = getApiKey("testKey", "testSecret")
apiClient = Spot(testKey, testSecret, base_url="https://testnet.binance.vision")


# 以基准币数量进行交易
def marketOrder(symbol, side, qty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quantity": qty,  # 基准币数量
    }
    response = apiClient.new_order(**params)
    print(response)
    return response


# 以计价币数量进行交易
def marketOrder2(symbol, side, quoteQty):
    params = {
        "symbol": symbol,
        "side": side,
        "type": "MARKET",
        "quoteOrderQty": quoteQty,  # 计价币数量
    }
    response = apiClient.new_order(**params)
    print(response)
    return response


# 处理K线消息
def message_handler(_, msg):
    # 把json字符串转为Python字典数据
    data = json.loads(msg)
    if "k" not in data:
        return
    symbol = data["k"]["s"]  # 交易对
    price = data["k"]["c"]  # 收盘价

    global btcusdtWaitStatus, ethbtcWaitStatus, ethusdtWaitStatus, btcusdt, ethbtc, ethusdt

    # 更新价格
    if btcusdtWaitStatus == 0 and symbol == "BTCUSDT":
        btcusdt = float(price)
        btcusdtWaitStatus = 1
    elif ethbtcWaitStatus == 0 and symbol == "ETHBTC":
        ethbtc = float(price)
        ethbtcWaitStatus = 1
    elif ethusdtWaitStatus == 0 and symbol == "ETHUSDT":
        ethusdt = float(price)
        ethusdtWaitStatus = 1

    # If all prices are updated, check for arbitrage opportunity
    if btcusdtWaitStatus == 1 and ethbtcWaitStatus == 1 and ethusdtWaitStatus == 1:
        print(
            "计算套利:",
            f"BTCUSDT={btcusdt}, ETHBTC={ethbtc}, ETHUSDT={ethusdt}",
        )
        checkProfit(btcusdt, ethbtc, ethusdt)
        btcusdtWaitStatus = 0
        ethbtcWaitStatus = 0
        ethusdtWaitStatus = 0


# 计算三个交易对交换后的盈利
def checkProfit(btcusdt, ethbtc, ethusdt):
    qty = 1000
    # 每笔交易扣除0.1%手续费
    btcQty = qty / btcusdt * 0.999
    ethQty = btcQty / ethbtc * 0.999
    usdt = ethQty * ethusdt * 0.999
    print("3次交易后的USDT数量:", round(usdt, 2))

    if usdt > 1000:
        print("出现套利机会")
        # 真正的下单数量50个USDT
        usdtQty = 50
        ord = marketOrder2("BTCUSDT", "BUY", usdtQty)
        if ord["status"] == "FILLED":
            btcQty = float(ord["executedQty"])
            print("获得BTC数量:", btcQty)
            ord2 = marketOrder2("ETHBTC", "BUY", btcQty)
            if ord2["status"] == "FILLED":
                ethQty = float(ord2["executedQty"])
                print("获得ETH数量:", ethQty)
                ord3 = marketOrder("ETHUSDT", "SELL", ethQty)
                if ord3["status"] == "FILLED":
                    usdt = float(ord3["cummulativeQuoteQty"])
                    print("获得USDT数量:", usdt, "利润:", usdt - usdtQty)
                    # 获得USDT数量: 49.43327 利润: -0.5667299999999997


# Main function to start the websocket client and subscribe to streams
def main():
    print("开始监测币价K线")
    client = SpotWebsocketStreamClient(on_message=message_handler)
    client.kline(symbol="BTCUSDT", interval="1m")
    client.kline(symbol="ETHBTC", interval="1m")
    client.kline(symbol="ETHUSDT", interval="1m")


if __name__ == "__main__":
    main()
