import os
import pathlib
from configparser import ConfigParser


# 获取币安的apikey和secret
def getApiKey(k, s):
    config = ConfigParser()
    config_file_path = os.path.join(
        pathlib.Path(__file__).parent.resolve(), ".", "config.ini"
    )
    config.read(config_file_path)
    return config["keys"][k], config["keys"][s]


# 获取欧易的apikey和secret
def getOkApiKey(k, s, p):
    config = ConfigParser()
    config_file_path = os.path.join(
        pathlib.Path(__file__).parent.resolve(), ".", "config.ini"
    )
    config.read(config_file_path)
    return config["keys"][k], config["keys"][s], config["keys"][p]
