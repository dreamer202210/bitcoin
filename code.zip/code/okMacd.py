import argparse
import pandas as pd
from okx import MarketData
from okx import Trade
from env import getOkApiKey
import time

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

tradeAPI = Trade.TradeAPI(
    apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
)

instId = "BTC-USDT-SWAP"  # 交易对
qty = 1  # 下单数量为张数，1张=0.001BTC
longSz = 0  # 开多数量
shortSz = 0  # 开空数量


# MACD信号策略
def macd_strategy(macd, signal):
    global instId, qty, longSz, shortSz

    if (
        isinstance(macd, pd.Series)
        and isinstance(signal, pd.Series)
        and len(macd) > 1
        and len(signal) > 1
    ):
        if macd.iloc[-1] > signal.iloc[-1]:  # 金叉
            print("出现金叉，建议做多")
            if longSz == 0:
                # 未开多则开多
                print("开仓做多")
                ord = NewOrd(instId, "buy", qty, "long")
                if ord["code"] == "0" and len(ord["data"]) > 0:
                    orderId = ord["data"][0]["ordId"]
                    fillPx, fillSz = getOrder(instId, orderId)
                    longSz = float(fillSz)
            if shortSz > 0:
                # 如果开空则平空
                print("平空")
                NewOrd(instId, "buy", shortSz, "short")
                shortSz = 0
        elif macd.iloc[-1] < signal.iloc[-1]:  # 死叉
            print("出现死叉，建议做空")
            if shortSz == 0:
                # 未开空则开空
                print("开仓做空")
                ord = NewOrd(instId, "sell", qty, "short")
                if ord["code"] == "0" and len(ord["data"]) > 0:
                    orderId = ord["data"][0]["ordId"]
                    fillPx, fillSz = getOrder(instId, orderId)
                    shortSz = float(fillSz)
            if longSz > 0:
                # 如果开多则平多
                print("平多")
                NewOrd(instId, "sell", longSz, "long")
                longSz = 0
        else:
            print("什么也不用做")
    else:
        print("数据不足")


# 获取K线数据
def getKlines(instId, bar, limit):
    marketApi = MarketData.MarketAPI(
        apiKey, apiSecretKey, passphrase, use_server_time=False, flag="1"
    )
    data = marketApi.get_candlesticks(instId=instId, bar=bar, limit=limit)
    # print(data)
    klines_data = data["data"]
    # print(klines_data)
    if all(isinstance(i, list) for i in klines_data):
        df = pd.DataFrame(
            klines_data,
            columns=[
                "ts",
                "o",
                "h",
                "l",
                "c",
                "?",
                "?",
                "?",
                "?",
            ],
        )
        # Convert the 'close' and 'open' columns to numeric values
        df["c"] = pd.to_numeric(df["c"])
        df["o"] = pd.to_numeric(df["o"])

        # Calculate the MACD and Signal lines
        exp1 = df["c"].ewm(span=12, adjust=False).mean()
        exp2 = df["c"].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        macd_strategy(macd, signal)
    else:
        print("Invalid klines data structure.")


# 开仓或平仓
def NewOrd(instId, side, qty, positionSide):
    result = tradeAPI.place_order(
        instId=instId,  # 交易对
        ccy="USDT",  # 保证金币种
        tdMode="isolated",  # 模式为逐仓
        side=side,  # 买卖方向为买入
        posSide=positionSide,  # 持仓方向，long为做多,short为做空
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量,单位为张数
    )
    print("开仓或平仓", result)
    return result


# 查询订单
def getOrder(instId, orderId):
    result = tradeAPI.get_order(instId, orderId)
    print("获取订单信息", result)
    fillPx = 0  # 成交价
    fillSz = 0  # 成交数量
    for i in range(len(result["data"])):
        fillPx += float(result["data"][i]["fillPx"])  # 累计成交价
        fillSz += float(result["data"][i]["fillSz"])  # 累计成交数量
    return fillPx / len(result["data"]), fillSz


def main():
    global symbol, qty
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
    parser.add_argument("--qty", "-q", type=float, help="下单数量", required=True)
    args = vars(parser.parse_args())

    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "symbol":
            symbol = args[key]
        elif key == "qty":
            qty = args[key]
    print(symbol, qty)

    interval = "15m"  # K线间隔为15分钟
    limit = 50  # K线数量
    print("MACD信号策略", symbol, interval)
    while True:
        getKlines(instId, interval, limit)
        time.sleep(30)  # 休眠30秒


if __name__ == "__main__":
    main()
