from solana.keypair import Keypair

# Generate a new private key
keypair = Keypair.generate()

# Get the public key (address) associated with the private key
public_key = keypair.public_key

print(f"Private Key: {keypair.secret_key}")
print(f"Address: {public_key}")
