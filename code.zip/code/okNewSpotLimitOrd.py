from okx import Trade
from env import getOkApiKey

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

# 币币限价下单
def main():
    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )
    result = tradeAPI.place_order(
        instId="BTC-USDT",  # 交易对
        tdMode="cash",  # 币币交易
        side="buy",  # 买入
        ordType="limit",  # 限价
        sz="0.01",  # 数量
        px="60000",  # 委托价格
    )
    print("币币限价下单结果", result)


if __name__ == "__main__":
    main()
