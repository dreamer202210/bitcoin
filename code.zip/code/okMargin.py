from okx import Account

apiKey = ""
apiSecretKey = ""
passphrase = ""
# flag:0实盘，flag:1模拟盘
accountAPI = Account.AccountAPI(apiKey, apiSecretKey, passphrase, False, flag="1")
# isoMode:逐仓保证金划转模式 ，type:业务线类型(MARGIN 币币杠杆,CONTRACTS 合约)
result = accountAPI.set_isolated_mode(isoMode="automatic", type="CONTRACTS")
print(result)
#返回结果
# {'code': '0', 'data': [{'isoMode': 'automatic'}], 'msg': ''}