# chatGPT优化
import argparse
import pandas as pd
from binance.spot import Spot

# Initialize the Binance Spot client
client = Spot()
symbol = "BTCUSDT"
interval = "15m"


def calculate_rsi(data, window=14):
    delta = data.diff()
    gain = (delta > 0) * delta
    loss = (delta < 0) * -delta

    rollUp = gain.rolling(window=window).mean()
    rollDown = loss.rolling(window=window).mean()

    rs = rollUp / rollDown
    rsi = 100 - (100 / (1 + rs))
    return rsi


def getKlines(symbol, interval, limit):
    try:
        klines_data = client.klines(symbol, interval, limit=limit)
        df = pd.DataFrame(
            klines_data,
            columns=[
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
                "?",
                "?",
                "?",
                "?",
                "?",
                "?",
            ],
        )
        df["close"] = pd.to_numeric(df["close"])
        rsi = calculate_rsi(df["close"])
        print(f"RSI: {rsi.iloc[-1]}")
        return rsi
    except Exception as e:
        print(f"Error retrieving data: {e}")


def main():
    limit = 50
    global symbol, interval
    rsi = getKlines(symbol, interval, limit)
    if rsi is not None:
        lastRsi = rsi.iloc[-1]
        if lastRsi >= 70:
            print("建议卖出")
        elif lastRsi <= 30:
            print("建议买入")
        else:
            print("建议持续观察")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="命令行参数")
    parser.add_argument("--symbol", "-s", type=str, help="交易对", required=True)
    parser.add_argument("--interval", "-i", type=str, help="频率", required=True)
    args = vars(parser.parse_args())
    # 获取所有参数
    for key in args:
        # print(f"命令行参数名:{key}，参数值:{args[key]}")
        if key == "symbol":
            symbol = args[key]
        elif key == "interval":
            interval = args[key]
    print("RSI信号策略", symbol, interval)
    main()
