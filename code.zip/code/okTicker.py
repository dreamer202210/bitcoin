import asyncio
import json

from okx.websocket.WsPublicAsync import WsPublicAsync


def publicCallback(message):
    try:
        msg = json.loads(message)
        print("数据", msg)
        print(msg["arg"]["instId"])
        print(msg["data"][0][3])
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
    except KeyError as e:
        print(f"Key error: {e} - the key is not in the JSON structure")
    # {"arg":{"channel":"index-candle1m","instId":"BTC-USDT"},"data":[["1710899220000","62233.7","62233.7","62224.6","62231.2","0"]]}
    # exception=KeyError('data')


async def main():
    # url = "wss://wspap.okx.com:8443/ws/v5/business?brokerId=9999"
    url = "wss://wsaws.okx.com:8443/ws/v5/business"
    ws = WsPublicAsync(url=url)
    await ws.start()
    args = []
    arg1 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "BTC-USDT"}
    args.append(arg1)
    arg2 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "ETH-BTC"}
    args.append(arg2)
    arg3 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "ETH-USDT"}
    args.append(arg3)
    await ws.subscribe(args, publicCallback)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())
