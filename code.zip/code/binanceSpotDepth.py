from binance.spot import Spot

# 现货账户
client = Spot()


# 深度信息
def getDepth(symbol, limit):
    arr = client.depth(symbol, limit=limit)
    print(arr)
    # 返回数据格式[["价格1"，"数量1"],["价格2"，"数量2"]...]
    # bids [['57124.96000000', '8.19983000'], ['57124.10000000', '0.26493000'], ['57122.08000000', '0.00009000']]
    # asks [['57124.97000000', '1.97211000'], ['57127.59000000', '0.12009000'], ['57127.69000000', '0.00721000']]
    print("买入价", arr["bids"][0][0])  # 取第一个价格
    print("卖出价", arr["asks"][-1][0])  # 取最后一个价格


def main():
    getDepth("BTCUSDT", 5)


if __name__ == "__main__":
    main()
