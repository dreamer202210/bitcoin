from tronpy.keys import PrivateKey

# 用随机数生成私钥
Private = PrivateKey.random()
# 用私钥生成公钥和地址
Address = Private.public_key.to_base58check_address()
print("私钥", Private)
print("地址", Address)

# 运行结果
# 私钥 938f85a3a866f932107b1e912a34bfa98de9d311f35d506d2bfeac4929ddf171
# 地址 TXP4ey31F66QEsgL76EFcdyvqtwg2DPhXh
