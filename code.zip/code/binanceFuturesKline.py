from binance.um_futures import UMFutures

client = UMFutures()
symbol = "BTCUSDT"
params = {
    "interval": "1m",
    "limit": 10
}
arr = client.klines(symbol, **params)
print(arr)
lastId = len(arr) - 1  # 最后一根K线数据,也就是最新数据
print("开盘价", arr[lastId][1])  # 开盘价
print("最高价", arr[lastId][2])  # 最高价
print("最低价", arr[lastId][3])  # 最低价
print("收盘价", arr[lastId][4])  # 收盘价

# 返回结果
# 开盘价 62059.60
# 最高价 62065.30
# 最低价 62059.60
# 收盘价 62065.20