import asyncio
import time

#当前时间戳，1713342339.2257404
start=time.time()

def takeTime():
    #时间戳单位是秒
    t = int(time.time()-start)
    return f"{t}秒"

async def taskA():
    print("运行任务A")
    await asyncio.sleep(10)
    

async def taskB():
    print("运行任务B")
    await asyncio.sleep(10)

async def taskExect():
    tasks=[taskA(),taskB()]
    await asyncio.gather(*tasks)
    print(f"任务结束!!耗时{takeTime()}")

asyncio.run(taskExect())
    