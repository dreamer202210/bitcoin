from binance.um_futures import UMFutures
from env import getApiKey
import time

# 正式环境
# key, secret = getApiKey("apiKey","apiSecret")
# client = UMFutures(key=key, secret=secret, base_url="https://api.binance.com")

# 测试网
key, secret = getApiKey("testFuturesKey", "testFuturesSecret")
client = UMFutures(key=key, secret=secret, base_url="https://testnet.binancefuture.com")

qty = 0.01
# 开仓做多
response = client.new_order(
    symbol="BTCUSDT",
    side="BUY",
    type="MARKET",
    quantity=qty,
    positionSide="LONG",
    # timeInForce="GTC",
)
print("开仓")
print(response)


response = client.new_order(
    symbol="BTCUSDT",
    side="SELL",
    type="TAKE_PROFIT_MARKET",
    timeInForce="GTC",
    stopPrice=64100,
    quantity=qty,
    positionSide="LONG",
)
print("设置止盈")
print(response)
ordId = response["orderId"]
print(f"止盈订单id{ordId}")
# 休眠10秒
time.sleep(10)

# 取消订单
response = client.cancel_order(
    symbol="BTCUSDT", orderId=ordId, recvWindow=2000
)
print("取消订单")
print(response)


# 取消所有打开的订单
# response = client.cancel_open_orders(
#     symbol="BTCUSDT", recvWindow=2000
# )
# print("取消所有打开的订单")
# print(response)