import asyncio
from okx.websocket.WsPublicAsync import WsPublicAsync
from okx import Trade
from okx import Account
from env import getOkApiKey
import json

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

# 等待三个交易对数据状态
btcusdtWaitStatus = 0
ethbtcWaitStatus = 0
ethusdtWaitStatus = 0
btcusdt = 0
ethbtc = 0
ethusdt = 0


# 下市价单
def marketOrder(symbol, side, qty):
    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )
    result = tradeAPI.place_order(
        instId=symbol,  # 交易对
        tdMode="cash",  # 模式为币币交易
        side=side,  # 买卖方向
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量
    )
    print("币币市价下单结果", result)
    return result


def publicCallback(msg):
    global btcusdtWaitStatus
    global ethbtcWaitStatus
    global ethusdtWaitStatus
    global btcusdt
    global ethbtc
    global ethusdt

    try:
        msg = json.loads(msg)
        # print("数据", msg)
        # print(msg["arg"]["instId"])
        # print(msg["data"][0][3])
        symbol = msg["arg"]["instId"]
        data = msg["data"]
        price = 0
        arrLen = len(data)  # 行情数据的行数
        if arrLen > 0:
            price = float(data[arrLen - 1][4])  # 最后一行第4列数据是最新收盘价格

        if btcusdtWaitStatus == 0 and symbol == "BTC-USDT":
            btcusdt = float(price)
            btcusdtWaitStatus = 1
        elif ethbtcWaitStatus == 0 and symbol == "ETH-BTC":
            ethbtc = float(price)
            ethbtcWaitStatus = 1
        elif ethusdtWaitStatus == 0 and symbol == "ETH-USDT":
            ethusdt = float(price)
            ethusdtWaitStatus = 1

        if btcusdtWaitStatus == 1 and ethbtcWaitStatus == 1 and ethusdtWaitStatus == 1:
            print(
                "开始计算三角套利",
                f"BTCUSDT={btcusdt},ETHBTC={ethbtc},ETHUSDT={ethusdt}",
            )
            checkProfit(btcusdt, ethbtc, ethusdt)
            # 清零
            btcusdtWaitStatus = 0
            ethbtcWaitStatus = 0
            ethusdtWaitStatus = 0
            # marketOrder("BTCUSDT", "buy", "0.05", "380")
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
    except KeyError as e:
        print(f"Key error: {e} - the key is not in the JSON structure")


# 计算盈利
def checkProfit(btcusdt, ethbtc, ethusdt):
    # 下单数量 1000usdt
    qty = 1000
    # 第1步用1000个usdt购买btc,并扣除0.1%手续费
    btc = qty / btcusdt * 0.999
    # 第2步用btc换成eth,并扣除0.1%手续费
    eth = btc / ethbtc * 0.999
    # 第3步用eth换回usdt,并扣除0.1%手续费
    usdt = eth * ethusdt * 0.999
    print("经过3次兑换后得到的usdt是", round(usdt, 2))
    if usdt > 996:
        # 账户usdt余额
        balalce = getBalance("USDT")
        print("账户余额", balalce)
        usdtQty = 50
        # 出现套利机会，下三个市价单
        print("出现套利机会，下三个市价单")
        ord = marketOrder("BTC-USDT", "buy", usdtQty)
        ordId = ord["data"][0]["ordId"]
        price1, sz1 = getOrd("BTC-USDT", ordId)
        print("BTC平均价格", price1, "兑换的BTC数量", sz1)

        ord2 = marketOrder("ETH-BTC", "buy", sz1)
        ordId2 = ord2["data"][0]["ordId"]
        price2, sz2 = getOrd("ETH-BTC", ordId2)
        print("ETH平均价格", price2, "兑换的ETH数量", sz2)

        ord3 = marketOrder("ETH-USDT", "sell", sz2)
        print(ord3)
        balalce2 = getBalance("USDT")
        print(f"三次交易后的账户余额{balalce}, 盈利={balalce2 - balalce}")


# 获取订单的平均价格和成交数量
def getOrd(instId, orderId):
    tradeAPI = Trade.TradeAPI(
        apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
    )
    result = tradeAPI.get_order(instId, orderId)
    print("获取订单信息", result)
    fillPx = 0  # 成交价
    fillSz = 0  # 成交数量
    if len(result["data"]) > 0:
        for i in range(len(result["data"])):
            fillPx += float(result["data"][i]["fillPx"])  # 累计成交价
            fillSz += float(result["data"][i]["fillSz"])  # 累计成交数量
        return fillPx / len(result["data"]), fillSz
    else:
        return 0, 0


# 账户余额
def getBalance(ccy):
    accountAPI = Account.AccountAPI(apiKey, apiSecretKey, passphrase, False, flag="1")
    acc = accountAPI.get_account_balance(ccy=ccy)
    balance = float(acc["data"][0]["details"][0]["availBal"])
    return balance


async def main():
    print("欧易三角套利策略")
    url = "wss://wsaws.okx.com:8443/ws/v5/business"
    ws = WsPublicAsync(url=url)
    await ws.start()
    args = []
    arg1 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "BTC-USDT"}
    args.append(arg1)
    arg2 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "ETH-BTC"}
    args.append(arg2)
    arg3 = {"channel": "index-candle1m", "instType": "SPOT", "instId": "ETH-USDT"}
    args.append(arg3)
    await ws.subscribe(args, publicCallback)
    # await asyncio.sleep(20)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())
