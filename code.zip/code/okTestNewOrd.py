from okx import MarketData
from okx import Trade
from okx import Account
from env import getOkApiKey
import pandas as pd
import time

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)

tradeAPI = Trade.TradeAPI(
    apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
)


# 开仓或平仓
def NewOrd(instId, side, qty, positionSide):
    result = tradeAPI.place_order(
        instId=instId,  # 交易对
        ccy="USDT",  # 保证金币种
        tdMode="isolated",  # 模式为逐仓
        side=side,  # 买卖方向为买入
        posSide=positionSide,  # 持仓方向，long为做多,short为做空
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量
    )
    print("开仓", result)
    return result


# 查询订单
def getOrder(instId, orderId):
    result = tradeAPI.get_order(instId, orderId)
    print("获取订单信息", result)
    fillPx = 0  # 成交价
    fillSz = 0  # 成交数量
    for i in range(len(result["data"])):
        fillPx += float(result["data"][i]["fillPx"])  # 累计成交价
        fillSz += float(result["data"][i]["fillSz"])  # 累计成交数量
    return fillPx / len(result["data"]), fillSz


def main():
    print("测试ok合约开仓下单api")
    instId = "BTC-USDT-SWAP"
    sz = 1  # 数量单位1张，0.001个BTC
    ord = NewOrd("BTC-USDT-SWAP", "buy", sz, "long")
    orderId = ord["data"][0]["ordId"]
    fillPx, fillSz = getOrder(instId, orderId)
    print(fillPx, fillSz)

    time.sleep(5)
    print("测试ok合约平仓下单api")
    ord = NewOrd("BTC-USDT-SWAP", "sell", sz, "long")
    orderId = ord["data"][0]["ordId"]
    fillPx, fillSz = getOrder(instId, orderId)
    print(fillPx, fillSz)
    print("测试ok合约平仓完成")

    # print("测试ok币币下单api")
    # instId = "BTC-USDT"
    # sz = 20  # 数量单位1个USDT
    # ord = NewOrd(instId, "buy", sz, "")
    # orderId = ord["data"][0]["ordId"]
    # fillPx, fillSz = getOrder(instId, orderId)
    # print(fillPx, fillSz)


if __name__ == "__main__":
    main()
