import time
from binance.websocket.um_futures.websocket_client import UMFuturesWebsocketClient
import json


# 接收推送数据
def message_handler(_, msg):
    data = json.loads(msg)
    # print(data)
    print("第1个买入价", data["b"][0][0])
    print("最后1个卖出价", data["a"][-1][0])
    # 运行结果
    # 第1个买入价 62066.30
    # 最后1个卖出价 62070.80


client = UMFuturesWebsocketClient(on_message=message_handler)
client.partial_book_depth(
    symbol="BTCUSDT",  # 交易对
    level=20,  # 数量
    speed=100,  # 更新速度，单位：毫秒
)

# time.sleep(10) #休眠10秒
# client.stop() #停止接收推送
