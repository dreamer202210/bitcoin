import asyncio
import json

from okx.websocket.WsPublicAsync import WsPublicAsync


def publicCallback(message):
    try:
        msg = json.loads(message)
        # Access 'arg' and 'instId'
        arg = msg.get("arg")
        if arg is not None and "instId" in arg:
            print(arg["instId"])

        # Access 'data', 'ask', and 'bid'
        data = msg.get("data")
        if data is not None:
            if "ask" in data:
                print(data["ask"])
            if "bid" in data:
                print(data["bid"])
    except json.JSONDecodeError as e:
        print("JSON decode error:", e)
    except KeyError as e:
        print(f"Key error: {e} - the key is not in the JSON structure")


async def main():

    url = "wss://wspap.okex.com:8443/ws/v5/public?brokerId=9999"
    # url = "wss://ws.okx.com:8443/ws/v5/business"
    ws = WsPublicAsync(url=url)
    await ws.start()
    args = []
    arg1 = {"channel": "books", "instType": "SPOT", "instId": "BTC-USDT"}
    args.append(arg1)
    await ws.subscribe(args, publicCallback)
    while True:
        await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(main())
