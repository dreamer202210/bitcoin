from okx import Trade
from env import getOkApiKey
import time

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)
tradeAPI = Trade.TradeAPI(
    apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
)


# 限价开仓
def newOrd(instId, qty):
    result = tradeAPI.place_order(
        instId=instId,  # 交易对
        ccy="USDT",  # 保证金币种
        tdMode="isolated",  # 模式为逐仓
        side="buy",  # 买卖方向为买入
        posSide="long",  # 持仓方向，long为做多,short为做空
        ordType="limit",  # 订单类型为市价单
        px="63000",  # 委托价格
        sz=qty,  # 下单数量
    )
    print("下限价单结果", result)
    return result


# 止盈单
def newProfitStoplossOrd(instId, qty):
    result = tradeAPI.place_order(
        instId=instId,
        tdMode="isolated",
        side="buy",
        posSide="long",
        ordType="limit",
        sz=qty,  # 数量
        px="63100.0",
        # attachAlgoOrds=arr
        tpTriggerPx="63110.0",  # 触发价格
        tpOrdPx="64000.0",  # 止盈价格
        tpTriggerPxType="last",  # 止盈触发价类型：last最新价格，index指数价格，mark标记价格
        slTriggerPx="63000.0",  # 触发价格
        slOrdPx="62000.0",  # 止损价格
        slTriggerPxType="last",  # 止损触发价类型：last最新价格，index指数价格，mark标记价格
    )
    print("止盈单结果", result)
    return result


# 获取订单信息
def getOrd(instId, orderId):
    result = tradeAPI.get_order(instId, orderId)
    print("获取订单信息", result)
    return result


# 取消订单
def cancelOrd(instId, orderId):
    result = tradeAPI.cancel_order(instId, orderId)
    print("取消订单结果", result)
    return result


# 合约限价下单
def main():
    instId = "BTC-USDT-SWAP"
    qty = "10"  # 下单数量10个usdt
    result = newOrd(instId, qty)
    data = result["data"]
    if len(data) > 0:
        orderId = data[0]["ordId"]
        ordInfo = getOrd(instId, orderId)
        print("订单详情", ordInfo)
        if len(ordInfo["data"]) > 0:
            state = ordInfo["data"][0]["state"]
            print("订单状态", state)
            if state == "live":
                time.sleep(10)  # 休眠10秒
                res = cancelOrd(instId, orderId)  # 取消订单
                print(res)

        # canceled：撤单成功,live：等待成交,partially_filled：部分成交,filled：完全成交
    # newProfitStoplossOrd(instId,qty)


if __name__ == "__main__":
    main()
