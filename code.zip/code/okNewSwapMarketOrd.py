from okx import Trade
from env import getOkApiKey
import time

apiKey, apiSecretKey, passphrase = getOkApiKey(
    "okTestKey", "okTestSecret", "passphrase"
)
tradeAPI = Trade.TradeAPI(
    apiKey, apiSecretKey, passphrase, False, flag="1"  # 0为实盘，1为模拟盘
)


# 市价开仓
def NewOrd(qty):
    result = tradeAPI.place_order(
        instId="BTC-USDT-SWAP",  # 交易对
        ccy="USDT",  # 保证金币种
        tdMode="isolated",  # 模式为逐仓
        side="buy",  # 买卖方向为买入
        posSide="long",  # 持仓方向，long为做多,short为做空
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量
    )
    print("市价开仓结果", result)


# 市价平仓
def CloseOrd(qty):
    result = tradeAPI.place_order(
        instId="BTC-USDT-SWAP",  # 交易对
        ccy="USDT",  # 保证金币种
        tdMode="isolated",  # 模式为逐仓
        side="sell",  # 买卖方向为买入
        posSide="long",  # 持仓方向，long为做多,short为做空
        ordType="market",  # 订单类型为市价单
        sz=qty,  # 下单数量
    )
    print("市价开仓结果", result)


# 合约市价下单
def main():
    qty = "10"  # 下单数量10个usdt
    NewOrd(qty)  # 开仓
    time.sleep(20)  # 休眠20秒
    CloseOrd(qty)  # 平仓


if __name__ == "__main__":
    main()
