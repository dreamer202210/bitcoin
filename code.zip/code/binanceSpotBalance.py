from binance.spot import Spot
from env import getApiKey


# 账户余额
def getBalance(symbol):
    # 正式网
    apiKey, apiSecret = getApiKey("apiKey", "apiSecret")
    print(apiKey, apiSecret)
    # 现货账户
    client = Spot(apiKey, apiSecret, base_url="https://api1.binance.com")
    response = client.user_asset(asset=symbol, recvWindow=5000)
    if len(response) > 0:
        return response[0]["free"]
    return 0
    

def main():
    SpotBalance = getBalance("USDT")
    print("现货账户USDT余额", SpotBalance)
    

if __name__ == "__main__":
    main()
