from binance.spot import Spot
from env import getApiKey


# 下一个市价单
def marketOrder(symbol, side, qty, price):
    # key, secret = getApiKey("apiKey","apiSecret")
    # client = Spot(key, secret, base_url="https://api.binance.com")

    # 测试网
    testKey, testSecret = getApiKey("testKey", "testSecret")
    client = Spot(testKey, testSecret, base_url="https://testnet.binance.vision")

    params = {
        "symbol": symbol,
        "side": side,
        "type": "LIMIT",
        "timeInForce": "GTC",
        "quantity": qty,
        "price": price,
    }

    response = client.new_order(**params)
    print(response)


def main():
    marketOrder("BNBUSDT", "BUY", "0.05", "380")


if __name__ == "__main__":
    main()
